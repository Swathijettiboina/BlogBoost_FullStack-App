import React  from 'react'

export const Profile = () => {
  return (
    <div className="flex justify-center items-center min-h-screen">

        <img src="https://freefrontend.com/assets/img/html-funny-404-pages/CodePen-404-Page.gif" alt="Funny 404 Gif" />
        </div>
  )
}
export default Profile;